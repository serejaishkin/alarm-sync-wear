# Keep-alive против force-stop будильника на часах

Портировано (с адаптацией под WakeSync) из найденного тобой
`ArmAGEDDon1109/wear-alarm-sync` — там задокументирован реальный кейс:
некоторые прошивки Wear OS (у них — OPLUS) через ~10 сек после выключения
экрана форс-стопят процесс приложения И **отменяют все его будильники**
через `removeAlarmsForPackage`, что уже не штатное поведение AlarmManager
(обычно alarms переживают смерть процесса).

**Не подтверждено как баг именно на Galaxy Watch 4** — это профилактика,
а не фикс подтверждённой проблемы. Дешёвая и безвредная: silent,
min-priority foreground-сервис, который просто существует пока есть хотя бы
один активный будильник.

## Файлы

- `WearAlarmKeepAliveService.kt` — новый файл, скопировать целиком
- `WearAlarmScheduler.kt` — заменить целиком (добавлены 3 вызова
  `WearAlarmKeepAliveService.refresh(context)`: после schedule(),
  scheduleSnooze(), cancel())
- `MANIFEST_SNIPPET.xml` — добавить блок `<service>` в
  `wear/src/main/AndroidManifest.xml`

## Куда класть

```
wear/src/main/java/com/sysadmindoc/alarmclock/wear/WearAlarmKeepAliveService.kt   ← новый файл
wear/src/main/java/com/sysadmindoc/alarmclock/wear/WearAlarmScheduler.kt          ← замена
wear/src/main/AndroidManifest.xml                                                  ← добавить <service> из MANIFEST_SNIPPET.xml
```

## Логика

`WearAlarmKeepAliveService.refresh(context)` — единственная точка входа.
Смотрит на ВЕСЬ список будильников в `WearAlarmListStore`, находит
ближайший будущий trigger среди enabled-записей:
- есть будущий будильник → `startForegroundService` с временем в тексте
  уведомления (silent, MIN priority, `VISIBILITY_SECRET` — не мешает)
- нет ни одного → `stopService`

Вызывается из `schedule()`/`scheduleSnooze()`/`cancel()` в
`WearAlarmScheduler`, а не привязан к жизненному циклу одного конкретного
будильника — это важно при нескольких будильниках: отмена одного не должна
останавливать защиту для остальных.

## Проверить перед мерджем

Единственное, что стоит явно потестировать на реальных часах — что
`specialUse` FGS с этим subtype реально стартует и не убивается системой
Wear OS 3+/One UI Watch (permission `FOREGROUND_SERVICE_SPECIAL_USE` у вас
уже объявлен для `WearAlarmFeedbackService`, так что инфраструктура на
месте).
